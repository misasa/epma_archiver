class ConnectionPool
  VERSION = "2.2.0"
end
