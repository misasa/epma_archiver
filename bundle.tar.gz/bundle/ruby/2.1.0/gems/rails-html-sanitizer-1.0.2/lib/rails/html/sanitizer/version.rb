module Rails
  module Html
    class Sanitizer
      VERSION = "1.0.2"
    end
  end
end
